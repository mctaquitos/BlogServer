// Router implementation omitted for brevity; user already has it.
